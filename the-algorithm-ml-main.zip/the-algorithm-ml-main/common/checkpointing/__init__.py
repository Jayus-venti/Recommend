from tml.common.checkpointing.snapshot import get_checkpoint, Snapshot
