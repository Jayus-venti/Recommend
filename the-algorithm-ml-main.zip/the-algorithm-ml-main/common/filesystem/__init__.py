from tml.common.filesystem.util import infer_fs, is_gcs_fs, is_local_fs
